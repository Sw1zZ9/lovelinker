from handlers import bot

if __name__ == '__main__':
    bot.remove_webhook()
    bot.polling(none_stop=True)
