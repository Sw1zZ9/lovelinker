import sqlite3
import os
import telebot

# Настройка бота
API_TOKEN = '7227497628:AAFLrW0jUivz7mHcpwtTsUs6bZ0GPfh8HRc'  # Замените на ваш токен бота
bot = telebot.TeleBot(API_TOKEN)


# Функция для получения имени пользователя по user_id
def get_telegram_username(user_id):
    try:
        user_info = bot.get_chat_member(chat_id=user_id, user_id=user_id)
        return user_info.user.username if user_info.user.username else "Неизвестно"
    except Exception as e:
        print(f"Ошибка при получении имени пользователя: {e}")
        return "Ошибка"


def delete_user_by_id(cursor, user_id):
    cursor.execute('DELETE FROM profiles WHERE user_id = ?', (user_id,))
    print(f"Профиль с user_id {user_id} удален.")


def delete_column_by_user_id(cursor, user_id, column):
    # Проверяем, существует ли столбец
    cursor.execute("PRAGMA table_info(profiles)")
    columns_info = cursor.fetchall()
    columns = {row[1]: row[3] for row in columns_info}  # row[1] - имя столбца, row[3] - NOT NULL constraint

    if column not in columns:
        print(f"Столбец {column} не существует.")
        return

    # Обновляем значение столбца на пустую строку или NULL в зависимости от NOT NULL constraint
    if column == 'photo':
        cursor.execute(f'UPDATE profiles SET {column} = "no_photo" WHERE user_id = ?', (user_id,))
    elif columns[column] == 1:  # NOT NULL constraint
        cursor.execute(f'UPDATE profiles SET {column} = "" WHERE user_id = ?', (user_id,))
    else:
        cursor.execute(f'UPDATE profiles SET {column} = NULL WHERE user_id = ?', (user_id,))

    print(f"Содержимое столбца {column} у пользователя с user_id {user_id} очищено.")


def delete_database_and_recreate(db_path):
    try:
        # Попытка удалить файл
        if os.path.exists(db_path):
            os.remove(db_path)
            print("База данных удалена.")
        else:
            print("Файл базы данных не найден.")

        # Создание нового пустого файла базы данных
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Создание таблиц
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS profiles (
                user_id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                age INTEGER NOT NULL,
                gender TEXT NOT NULL DEFAULT "не указано",
                bio TEXT NOT NULL,
                photo TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS likes (
                user_id INTEGER,
                liked_user_id INTEGER,
                PRIMARY KEY (user_id, liked_user_id)
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS dislikes (
                user_id INTEGER,
                disliked_user_id INTEGER,
                PRIMARY KEY (user_id, disliked_user_id)
            )
        ''')
        conn.commit()
        conn.close()
        print("Новая база данных создана.")

    except PermissionError as e:
        print(f"Ошибка при удалении базы данных: {e}")


def main():
    db_path = 'dating_app.db'

    print("Выберите действие:")
    print("1 - Удаление записи по user_id")
    print("2 - Удаление конкретного столбца у user_id")
    print("3 - Полное удаление базы данных")
    print("4 - Получение имени пользователя Telegram по user_id")

    choice = input("Введите номер действия: ")

    # Создаем соединение с базой данных
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    if choice == '1':
        user_id = input("Введите user_id для удаления: ")
        delete_user_by_id(cursor, user_id)

    elif choice == '2':
        user_id = input("Введите user_id для удаления столбца: ")
        column = input("Введите имя столбца для удаления: ")
        delete_column_by_user_id(cursor, user_id, column)

    elif choice == '3':
        confirmation = input("Введите 'ПОДТВЕРДИТЬ' для полного удаления базы данных: ")
        if confirmation == 'ПОДТВЕРДИТЬ':
            # Закрываем соединение с базой данных перед удалением файла
            conn.close()
            # Удаляем файл и создаем новый
            delete_database_and_recreate(db_path)
        else:
            print("Удаление базы данных отменено.")

    elif choice == '4':
        user_id = int(input("Введите user_id для получения имени пользователя Telegram: "))
        username = get_telegram_username(user_id)
        print(f"Имя пользователя Telegram для user_id {user_id}: {username}")

    else:
        print("Неверный выбор.")

    if choice != '3':
        conn.commit()
        conn.close()


if __name__ == '__main__':
    main()
